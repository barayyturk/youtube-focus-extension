import { WORD_CLUSTERS } from "./associations-data.js";

const TAB_STATE_PREFIX = "tabState:";
const DEFAULT_SETTINGS = {
  enabled: true,
  mode: "topic",
  topic: "",
  anchorText: "",
  anchorUrl: "",
  broadenAssociations: true,
  associations: {}
};

// Only expand associations for the first handful of core words. Anchor
// text in particular can run long, and beyond this the video's own
// title/description already supplies plenty of matching vocabulary.
const MAX_WORDS_TO_EXPAND = 8;

const STOP_WORDS = new Set([
  "about", "after", "also", "and", "are", "from", "for", "how", "into",
  "its", "more", "not", "that", "the", "this", "using", "what", "when",
  "where", "with", "your"
]);

function meaningfulWords(value) {
  return [...new Set(
    (value || "")
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((word) => word.length > 2 && !STOP_WORDS.has(word))
  )].slice(0, MAX_WORDS_TO_EXPAND);
}

// Built once from the bundled cluster data: every word in a cluster maps to
// every other word in that same cluster. Purely local - no network, no
// expiry, nothing that can be rate-limited or taken away.
const WORD_ASSOCIATIONS = (() => {
  const map = new Map();
  for (const cluster of WORD_CLUSTERS) {
    for (const word of cluster) {
      const related = map.get(word) ?? new Set();
      for (const other of cluster) {
        if (other !== word) {
          related.add(other);
        }
      }
      map.set(word, related);
    }
  }
  return map;
})();

// Cheap singular/plural normalization so "doctors" still finds the
// "doctor" cluster without needing every plural form listed explicitly.
function singularize(word) {
  if (word.endsWith("ies") && word.length > 4) {
    return `${word.slice(0, -3)}y`;
  }
  if (word.endsWith("es") && word.length > 4) {
    return word.slice(0, -2);
  }
  if (word.endsWith("s") && !word.endsWith("ss") && word.length > 3) {
    return word.slice(0, -1);
  }
  return word;
}

function getLocalAssociations(word) {
  return (
    WORD_ASSOCIATIONS.get(word) ??
    WORD_ASSOCIATIONS.get(singularize(word)) ??
    null
  );
}

function getAssociationsForWords(words) {
  const result = {};
  for (const word of words) {
    const related = getLocalAssociations(word);
    if (related) {
      result[word] = [...related];
    }
  }
  return result;
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...settings };
}

function resolveSettings(rawSettings) {
  const settings = { ...DEFAULT_SETTINGS, ...rawSettings };

  if (!settings.broadenAssociations) {
    return { ...settings, associations: {} };
  }

  const target = settings.mode === "anchor" ? settings.anchorText : settings.topic;
  settings.associations = getAssociationsForWords(meaningfulWords(target));
  return settings;
}

/**
 * The service worker is intentionally small in Step 1.
 * It owns cross-tab state and gives later classification code one stable
 * place to receive navigation events.
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_SETTINGS") {
    getSettings().then((settings) => {
      sendResponse({ ok: true, settings: resolveSettings(settings) });
    });
    return true;
  }

  if (message?.type === "SAVE_SETTINGS") {
    const settings = resolveSettings(message.settings);
    chrome.storage.local
      .set({ settings })
      .then(() => sendResponse({ ok: true, settings }))
      .catch(() => sendResponse({ ok: false, error: "Could not save focus." }));
    return true;
  }

  if (message?.type !== "YOUTUBE_VIDEO_NAVIGATED") {
    return false;
  }

  const tabId = sender.tab?.id;
  if (typeof tabId !== "number") {
    sendResponse({ ok: false, error: "Navigation message has no tab id." });
    return false;
  }

  const state = {
    tabId,
    videoId: message.videoId ?? null,
    url: message.url ?? "",
    title: message.title ?? "",
    detectedAt: new Date().toISOString()
  };

  chrome.storage.session.set({ [`${TAB_STATE_PREFIX}${tabId}`]: state });
  console.info("[YouTube Focus] video navigation", state);

  sendResponse({ ok: true, state });
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove(`${TAB_STATE_PREFIX}${tabId}`);
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get("settings").then(({ settings }) => {
    if (settings) {
      return;
    }

    return chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
  });
});