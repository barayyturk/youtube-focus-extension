(() => {
  const YOUTUBE_ORIGIN = "https://www.youtube.com";
  let lastNavigationKey = "";
  let navigationTimer;
  let enforcementTimer;
  let settings = {
    enabled: true,
    mode: "topic",
    topic: "",
    anchorText: "",
    anchorUrl: "",
    broadenAssociations: true,
    // Map of core topic word -> array of related words fetched by the
    // background worker (e.g. { medicine: ["doctor", "hospital", ...] }).
    associations: {}
  };
  let blockedVideoId = "";
  const MIN_CONTEXT_LENGTH = 12;
  const BLOCK_CONFIRM_DELAY_MS = 400;
  const relevantVideoIds = new Set();
  let pendingBlockVideoId = null;
  let pendingBlockTimer;

  function clearPendingBlock() {
    pendingBlockVideoId = null;
    window.clearTimeout(pendingBlockTimer);
  }

  function isContextLoaded(context) {
    // YouTube renders the title before the description finishes hydrating.
    // Treat a too-short context as "not loaded yet" rather than "no match",
    // otherwise a video briefly reads as off-topic before its own
    // description has appeared in the DOM.
    return context.trim().length >= MIN_CONTEXT_LENGTH;
  }

  function getVideoId(url = window.location.href) {
    try {
      const parsedUrl = new URL(url, YOUTUBE_ORIGIN);

      if (parsedUrl.pathname === "/watch") {
        return parsedUrl.searchParams.get("v");
      }

      if (parsedUrl.pathname.startsWith("/shorts/")) {
        return parsedUrl.pathname.split("/")[2] || null;
      }

      if (parsedUrl.pathname.startsWith("/live/")) {
        return parsedUrl.pathname.split("/")[2] || null;
      }
    } catch {
      return null;
    }

    return null;
  }

  function isVideoPage(url = window.location.href) {
    return Boolean(getVideoId(url));
  }

  function getVideoTitle() {
    const title =
      document.querySelector("h1.ytd-watch-metadata yt-formatted-string") ||
      document.querySelector("h1.title") ||
      document.querySelector("title");

    return title?.textContent?.trim() ?? "";
  }

  function getVideoDescription() {
    const descriptionEl =
      document.querySelector("#description-inline-expander") ||
      document.querySelector("#description");
    const domDescription = descriptionEl?.textContent?.trim() ?? "";

    // The DOM description can lag behind (collapsed "show more" panel not
    // yet hydrated). og:description usually carries the full text as soon
    // as YouTube updates the document head, so prefer whichever is longer.
    const ogDescription =
      document
        .querySelector('meta[property="og:description"]')
        ?.getAttribute("content")
        ?.trim() ?? "";

    return domDescription.length >= ogDescription.length ? domDescription : ogDescription;
  }

  function getVideoChannel() {
    const channel =
      document.querySelector("ytd-channel-name #text") ||
      document.querySelector("#channel-name #text") ||
      document.querySelector('link[itemprop="name"]');

    return (channel?.textContent || channel?.getAttribute?.("content") || "").trim();
  }

  // Tags aren't rendered visibly, but YouTube still writes them (and the
  // video's category) into <head> meta tags that update on SPA navigation.
  function getVideoKeywordsAndCategory() {
    const keywords =
      document.querySelector('meta[name="keywords"]')?.getAttribute("content") ?? "";
    const category =
      document.querySelector('meta[itemprop="genre"]')?.getAttribute("content") ?? "";

    return [keywords, category].filter(Boolean).join(" ");
  }

  function getVideoHashtags() {
    return [
      ...document.querySelectorAll(
        "#super-title a, ytd-metadata-row-container-renderer a, a.yt-simple-endpoint[href^='/hashtag/']"
      )
    ]
      .map((el) => el.textContent.trim())
      .filter(Boolean)
      .join(" ");
  }

  function getVideoContext() {
    return [
      getVideoTitle(),
      getVideoDescription(),
      getVideoChannel(),
      getVideoKeywordsAndCategory(),
      getVideoHashtags()
    ]
      .filter(Boolean)
      .join(" ")
      .trim();
  }

  function meaningfulWords(value) {
    const stopWords = new Set([
      "about", "after", "also", "and", "are", "from", "for", "how", "into",
      "its", "more", "not", "that", "the", "this", "using", "what", "when",
      "where", "with", "your"
    ]);

    return [...new Set(
      value
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, " ")
        .split(/\s+/)
        .filter((word) => word.length > 2 && !stopWords.has(word))
    )];
  }

  // Cheap singular/plural normalization (kept identical in spirit to the
  // one used when building the bundled association clusters) so a plural
  // in the video's title/description - "programmers" - still lines up
  // with a singular cluster entry - "programmer" - instead of missing by
  // a literal character mismatch.
  function singularize(word) {
    if (word.endsWith("ies") && word.length > 4) {
      return `${word.slice(0, -3)}y`;
    }
    if (word.endsWith("es") && word.length > 4) {
      return word.slice(0, -2);
    }
    if (word.endsWith("s") && !word.endsWith("ss") && word.length > 3) {
      return word.slice(0, -1);
    }
    return word;
  }

  function isRelevant(context) {
    const target = settings.mode === "anchor" ? settings.anchorText : settings.topic;
    const targetWords = meaningfulWords(target);

    if (!settings.enabled || targetWords.length === 0) {
      return true;
    }

    // settings.associations maps each core topic word to a broader set of
    // related words (e.g. "medicine" -> "doctor", "clinic", "hospital"...),
    // drawn from a word-cluster dictionary bundled with the extension (see
    // src/associations-data.js) - no network calls involved. A video only
    // has to contain the literal topic word OR one of its known
    // associations - "doctor" in the title now legitimately counts toward
    // a "Medicine" focus even though the word "medicine" never appears on
    // the page.
    const expandedTargetWords = new Set(targetWords);
    for (const word of targetWords) {
      const related = settings.associations?.[word];
      if (Array.isArray(related)) {
        related.forEach((relatedWord) => expandedTargetWords.add(relatedWord));
      }
    }

    const normalizedTargetWords = new Set([...expandedTargetWords].map(singularize));
    const normalizedContextWords = new Set(meaningfulWords(context).map(singularize));
    const matches = [...normalizedTargetWords].filter((word) => normalizedContextWords.has(word)).length;
    // The threshold is still based on the literal topic word count (not the
    // expanded set), so a single-word topic like "Medicine" only needs one
    // hit - whether that hit is the word itself or a known association.
    const threshold = targetWords.length === 1 ? 1 : Math.max(1, Math.ceil(targetWords.length / 3));

    return matches >= threshold;
  }

  function removeBlocker() {
    document.querySelector("#youtube-focus-blocker")?.remove();
    document.documentElement.style.removeProperty("overflow");
  }

  function showBlocker() {
    if (document.querySelector("#youtube-focus-blocker")) {
      return;
    }

    const video = document.querySelector("video");
    video?.pause();

    const blocker = document.createElement("div");
    blocker.id = "youtube-focus-blocker";
    blocker.innerHTML = `
      <div class="youtube-focus-card" role="dialog" aria-modal="true" aria-labelledby="youtube-focus-title">
        <div class="youtube-focus-mark">FOCUS MODE</div>
        <h2 id="youtube-focus-title">Stay with your intention</h2>
        <p>This video doesn’t match your active focus. Going back keeps your session on track.</p>
        <button id="youtube-focus-go-back" type="button">Go back to focus</button>
      </div>
    `;

    const style = document.createElement("style");
    style.textContent = `
      #youtube-focus-blocker {
        position: fixed; inset: 0; z-index: 2147483647;
        display: grid; place-items: center; padding: 24px;
        background: rgba(8, 12, 28, .94); color: #f7f8ff;
        font-family: Inter, ui-sans-serif, system-ui, sans-serif;
      }
      .youtube-focus-card {
        width: min(420px, 100%); padding: 36px; text-align: center;
        border: 1px solid rgba(255,255,255,.14); border-radius: 24px;
        background: linear-gradient(145deg, #171f43, #0e142c);
        box-shadow: 0 24px 100px rgba(0,0,0,.5);
      }
      .youtube-focus-mark {
        color: #8be9c2; font-size: 11px; font-weight: 800;
        letter-spacing: .16em; margin-bottom: 18px;
      }
      .youtube-focus-card h2 { margin: 0 0 12px; font-size: 28px; }
      .youtube-focus-card p { color: #b7bfd9; line-height: 1.6; margin: 0 0 26px; }
      #youtube-focus-go-back {
        border: 0; border-radius: 999px; padding: 13px 22px;
        background: #8be9c2; color: #07151a; font-weight: 800; cursor: pointer;
      }
      #youtube-focus-go-back:hover { background: #b5f5d9; }
    `;

    blocker.append(style);
    document.documentElement.append(blocker);
    document.documentElement.style.overflow = "hidden";
    blocker.querySelector("#youtube-focus-go-back").addEventListener("click", () => {
      window.history.back();
    });
  }

  function enforceFocus() {
    const videoId = getVideoId();
    if (!videoId || !isVideoPage() || !settings.enabled) {
      blockedVideoId = "";
      clearPendingBlock();
      removeBlocker();
      return;
    }

    // Once a video has been confirmed relevant, don't re-litigate it on
    // every subsequent DOM mutation (chat messages, view-count ticks,
    // related-video re-renders, etc. all fire the observer repeatedly).
    if (relevantVideoIds.has(videoId)) {
      if (blockedVideoId === videoId) {
        blockedVideoId = "";
        removeBlocker();
      }
      clearPendingBlock();
      return;
    }

    const context = getVideoContext();

    // The description hydrates a beat after the title. If we judge
    // relevance against a not-yet-loaded context, it looks like "no match"
    // and the blocker flashes on for a related video before the real
    // description arrives. Wait for enough content instead of guessing.
    if (!isContextLoaded(context)) {
      return;
    }

    if (isRelevant(context)) {
      relevantVideoIds.add(videoId);
      blockedVideoId = "";
      clearPendingBlock();
      removeBlocker();
      return;
    }

    // Require the "not relevant" verdict to hold for a short window before
    // actually showing the blocker, so a single transient re-render (e.g.
    // YouTube swapping the description panel) can't cause a flash-block.
    if (pendingBlockVideoId === videoId) {
      return;
    }

    pendingBlockVideoId = videoId;
    window.clearTimeout(pendingBlockTimer);
    pendingBlockTimer = window.setTimeout(() => {
      if (pendingBlockVideoId !== videoId || getVideoId() !== videoId) {
        return;
      }

      const recheckedContext = getVideoContext();
      if (!isContextLoaded(recheckedContext) || isRelevant(recheckedContext)) {
        // Context changed while we waited (still loading, or turned out
        // relevant after all) - don't block based on stale info.
        if (isContextLoaded(recheckedContext) && isRelevant(recheckedContext)) {
          relevantVideoIds.add(videoId);
        }
        return;
      }

      if (blockedVideoId !== videoId) {
        blockedVideoId = videoId;
        showBlocker();
      }
    }, BLOCK_CONFIRM_DELAY_MS);
  }

  function publishNavigation(reason) {
    const url = window.location.href;
    const videoId = getVideoId(url);
    const navigationKey = `${videoId ?? "not-a-video"}:${url}`;

    if (navigationKey === lastNavigationKey) {
      return;
    }

    lastNavigationKey = navigationKey;
    chrome.runtime.sendMessage(
      {
        type: "YOUTUBE_VIDEO_NAVIGATED",
        reason,
        videoId,
        url,
        title: getVideoTitle(),
        context: getVideoContext()
      },
      () => {
        // A page can be unloading while the service worker is asleep.
        // The event is best-effort in this first detection-only slice.
        void chrome.runtime.lastError;
      }
    );
    enforceFocus();
  }

  function scheduleNavigationCheck(reason) {
    window.clearTimeout(navigationTimer);
    navigationTimer = window.setTimeout(() => publishNavigation(reason), 100);
  }

  function patchHistoryMethod(methodName) {
    const original = window.history[methodName];

    window.history[methodName] = function patchedHistoryMethod(...args) {
      const result = original.apply(this, args);
      scheduleNavigationCheck(`history.${methodName}`);
      return result;
    };
  }

  patchHistoryMethod("pushState");
  patchHistoryMethod("replaceState");
  window.addEventListener("popstate", () => scheduleNavigationCheck("popstate"));
  window.addEventListener("yt-navigate-finish", () =>
    scheduleNavigationCheck("yt-navigate-finish")
  );

  const observer = new MutationObserver(() => {
    if (isVideoPage() && !lastNavigationKey) {
      scheduleNavigationCheck("dom-ready");
    }
    if (isVideoPage()) {
      window.clearTimeout(enforcementTimer);
      enforcementTimer = window.setTimeout(enforceFocus, 250);
    }
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  scheduleNavigationCheck("initial-load");

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "GET_CURRENT_VIDEO") {
      sendResponse({
        ok: true,
        videoId: getVideoId(),
        url: window.location.href,
        title: getVideoTitle(),
        context: getVideoContext()
      });
      return false;
    }

    if (message?.type === "SET_SETTINGS") {
      settings = { ...settings, ...message.settings };
      // The focus topic/anchor just changed, so any cached "relevant"
      // verdicts (and any in-flight block decision) are stale.
      relevantVideoIds.clear();
      clearPendingBlock();
      enforceFocus();
      sendResponse({ ok: true });
      return false;
    }
  });

  chrome.runtime.sendMessage({ type: "GET_SETTINGS" }, (response) => {
    if (chrome.runtime.lastError || !response?.settings) {
      return;
    }
    settings = { ...settings, ...response.settings };
    relevantVideoIds.clear();
    clearPendingBlock();
    enforceFocus();
  });
})();