// A permanent, offline word-association dataset bundled with the extension.
//
// Each entry is a cluster of words that commonly belong to the same topic.
// Any word in a cluster is treated as "associated with" every other word in
// that same cluster - e.g. a "Medicine" focus also recognizes "doctor",
// "hospital", "clinic", and so on, even when the word "medicine" itself
// never appears on a video's page.
//
// This intentionally trades some breadth (it can't cover every possible
// niche topic the way a live statistical API could) for something that
// works forever: no network calls, no API keys, no rate limits, and no
// dependency on a third party staying online or staying free.
//
// It's just a plain data file - extend it any time by adding more clusters
// or more words to an existing cluster.
export const WORD_CLUSTERS = [
  ["medicine", "doctor", "physician", "hospital", "clinic", "nurse", "treatment", "diagnosis", "therapy", "patient", "surgery", "pharmacy", "medical", "health", "illness", "disease", "symptom", "prescription", "medication", "healthcare"],
  ["fitness", "exercise", "workout", "gym", "training", "cardio", "strength", "muscle", "weightlifting", "running", "stretching", "endurance", "athlete", "coach", "wellness", "bodybuilding"],
  ["nutrition", "diet", "calories", "protein", "vitamins", "minerals", "macros", "healthy", "eating", "meal", "metabolism", "supplements"],
  ["cooking", "recipe", "kitchen", "chef", "baking", "ingredients", "food", "cuisine", "culinary", "dish", "restaurant", "cook", "grill", "sauce", "meal"],
  ["programming", "coding", "code", "developer", "software", "programmer", "javascript", "python", "engineer", "algorithm", "debugging", "github", "application", "backend", "frontend", "database", "computer", "script"],
  ["technology", "tech", "gadget", "device", "smartphone", "computer", "hardware", "innovation", "electronics", "robotics", "artificial intelligence", "internet", "digital"],
  ["finance", "money", "investing", "investment", "stock", "budget", "savings", "income", "wealth", "economy", "bank", "banking", "trading", "market", "financial", "retirement", "tax"],
  ["business", "entrepreneur", "startup", "company", "management", "strategy", "leadership", "corporate", "industry", "enterprise", "profit", "revenue"],
  ["marketing", "advertising", "branding", "seo", "content", "social media", "campaign", "promotion", "audience", "customer", "sales"],
  ["sports", "athlete", "team", "game", "competition", "championship", "coach", "tournament", "league", "match", "player", "score"],
  ["gaming", "videogame", "game", "gamer", "esports", "console", "playstation", "xbox", "nintendo", "streamer", "twitch", "multiplayer"],
  ["music", "song", "band", "singer", "album", "concert", "instrument", "guitar", "piano", "melody", "lyrics", "musician", "orchestra", "rhythm"],
  ["art", "painting", "drawing", "artist", "design", "sketch", "illustration", "gallery", "canvas", "creative", "sculpture", "aesthetic"],
  ["photography", "photo", "camera", "lens", "photographer", "shoot", "portrait", "editing", "exposure", "composition"],
  ["film", "movie", "cinema", "director", "actor", "actress", "screenplay", "hollywood", "documentary", "scene", "script"],
  ["science", "research", "experiment", "scientist", "laboratory", "theory", "discovery", "hypothesis", "data"],
  ["physics", "quantum", "energy", "matter", "motion", "force", "gravity", "relativity", "particle", "mechanics"],
  ["biology", "cell", "organism", "genetics", "dna", "evolution", "species", "ecosystem", "anatomy", "microbiology"],
  ["chemistry", "chemical", "reaction", "molecule", "compound", "element", "laboratory", "acid", "formula"],
  ["astronomy", "space", "universe", "planet", "star", "galaxy", "nasa", "telescope", "cosmos", "astronaut"],
  ["mathematics", "math", "algebra", "geometry", "calculus", "equation", "number", "formula", "statistics", "theorem"],
  ["history", "historical", "ancient", "war", "civilization", "empire", "century", "historian", "archaeology", "revolution"],
  ["psychology", "mental health", "therapy", "mind", "behavior", "emotion", "anxiety", "counseling", "therapist", "wellbeing", "mindfulness"],
  ["meditation", "yoga", "mindfulness", "breathing", "relaxation", "zen", "spiritual", "wellness", "calm"],
  ["spirituality", "religion", "faith", "prayer", "meditation", "church", "belief", "sacred"],
  ["education", "learning", "school", "student", "teacher", "university", "college", "study", "classroom", "curriculum", "academic"],
  ["language", "vocabulary", "grammar", "fluent", "speaking", "translation", "linguistics", "pronunciation"],
  ["writing", "author", "novel", "book", "literature", "poetry", "story", "fiction", "editor", "manuscript"],
  ["law", "legal", "lawyer", "attorney", "court", "justice", "judge", "litigation", "regulation", "contract"],
  ["politics", "government", "election", "policy", "senator", "president", "democracy", "congress", "vote", "legislation"],
  ["economics", "economy", "market", "inflation", "gdp", "trade", "supply", "demand", "fiscal", "monetary"],
  ["travel", "trip", "vacation", "destination", "tourism", "flight", "hotel", "backpacking", "itinerary", "adventure"],
  ["nature", "environment", "wildlife", "ecosystem", "conservation", "climate", "sustainability", "ecology", "forest", "ocean"],
  ["automotive", "car", "vehicle", "engine", "driving", "mechanic", "motor", "racing", "garage"],
  ["diy", "home improvement", "renovation", "repair", "tools", "construction", "carpentry", "remodel"],
  ["gardening", "garden", "plant", "soil", "flowers", "vegetables", "landscaping", "botany"],
  ["parenting", "parent", "child", "family", "baby", "toddler", "kids", "newborn"],
  ["fashion", "style", "clothing", "outfit", "designer", "trend", "wardrobe", "accessories"]
];
